// O2Taxi shared components
(function() {
  const currentPath = window.location.pathname;
  function isActive(href) {
    if (href === '/' || href === '/index.html') return currentPath === '/' || currentPath === '/index.html';
    return currentPath.startsWith(href);
  }

  const links = [
    { href: '/', label: 'Home' },
    { href: '/airport-transfers/', label: 'Airport Transfers' },
    { href: '/local-taxi/', label: 'Local Taxi' },
    { href: '/prices/', label: 'Prices' },
    { href: '/train-station/', label: 'Train Stations' },
    { href: '/long-distance/', label: 'Long Distance' },
    { href: '/delivery-service/', label: 'Deliveries' },
    { href: '/pub-club-taxi/', label: 'Pub & Club' },
    { href: '/book/', label: '📞 Book Now', cta: true },
  ];

  const navHTML = `
    <nav>
      <div class="nav-inner">
        <a href="/" class="nav-logo">O2<span>Taxi</span></a>
        <button class="nav-toggle" aria-label="Menu" id="navToggle">
          <span></span><span></span><span></span>
        </button>
        <ul class="nav-links" id="navLinks">
          ${links.map(l => `<li><a href="${l.href}"${isActive(l.href) ? ' class="active"' : ''}${l.cta ? ' class="nav-cta"' : ''}>${l.label}</a></li>`).join('')}
        </ul>
      </div>
    </nav>
  `;

  const footerHTML = `
    <footer>
      <div class="footer-grid">
        <div>
          <a href="/" class="footer-logo">O2<span>Taxi</span></a>
          <p class="footer-desc">Reliable, professional taxi service based in Thame, Oxfordshire. Local journeys, airport transfers &amp; long-distance travel — available 24/7.</p>
          <div style="margin-top:18px; display:flex; gap:14px;">
            <a href="https://wa.me/+447923360048" style="color:#25d366; font-size:1.4rem; text-decoration:none;" aria-label="WhatsApp">💬</a>
            <a href="https://www.facebook.com/share/15peNKsMhj/" style="color:#4267B2; font-size:1.4rem; text-decoration:none;" aria-label="Facebook">📘</a>
            <a href="tel:+447923360048" style="color:var(--gold); font-size:1.4rem; text-decoration:none;" aria-label="Call">📞</a>
          </div>
        </div>
        <div class="footer-col">
          <h4>Services</h4>
          <ul>
            <li><a href="/airport-transfers/">Airport Transfers</a></li>
            <li><a href="/local-taxi/">Local Taxi</a></li>
            <li><a href="/long-distance/">Long Distance</a></li>
            <li><a href="/train-station/">Train Stations</a></li>
            <li><a href="/delivery-service/">Deliveries</a></li>
            <li><a href="/pub-club-taxi/">Pub &amp; Club</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Airports</h4>
          <ul>
            <li><a href="/airport-transfers/heathrow/">Heathrow Airport</a></li>
            <li><a href="/airport-transfers/gatwick/">Gatwick Airport</a></li>
            <li><a href="/airport-transfers/luton/">Luton Airport</a></li>
            <li><a href="/airport-transfers/stansted/">Stansted Airport</a></li>
            <li><a href="/airport-transfers/birmingham/">Birmingham Airport</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Company</h4>
          <ul>
            <li><a href="/about/">About Us</a></li>
            <li><a href="/prices/">Price Guide</a></li>
            <li><a href="/contact/">Contact</a></li>
            <li><a href="/book/">Book a Taxi</a></li>
            <li><a href="/blog/">Blog</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <div>© 2025 O2Taxi Thame. All rights reserved. | <a href="/privacy/">Privacy Policy</a> | <a href="/terms/">Terms of Service</a></div>
        <div>📍 Thame, Oxfordshire | <a href="tel:+447923360048">07923 360048</a></div>
      </div>
    </footer>
    <a href="https://wa.me/+447923360048?text=Hi%20O2Taxi%2C%20I%27d%20like%20to%20book%20a%20taxi%20please" class="whatsapp-float" aria-label="WhatsApp O2Taxi">💬</a>
  `;

  // Inject
  const navEl = document.getElementById('nav-placeholder');
  const footerEl = document.getElementById('footer-placeholder');
  if (navEl) navEl.outerHTML = navHTML;
  if (footerEl) footerEl.outerHTML = footerHTML;

  // Toggle
  document.addEventListener('click', function(e) {
    const toggle = document.getElementById('navToggle');
    const navLinks = document.getElementById('navLinks');
    if (toggle && navLinks) {
      if (toggle.contains(e.target)) navLinks.classList.toggle('open');
      else if (!navLinks.contains(e.target)) navLinks.classList.remove('open');
    }
    // FAQ
    if (e.target.closest('.faq-question')) {
      const item = e.target.closest('.faq-item');
      item.classList.toggle('open');
    }
  });
})();
