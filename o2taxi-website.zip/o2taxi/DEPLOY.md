# O2Taxi Website – Cloudflare Pages Deployment Guide

## What's in This Package

| File/Folder | Purpose |
|---|---|
| `index.html` | Homepage |
| `airport-transfers/` | Airport hub + 5 airport sub-pages |
| `local-taxi/` | Local taxi hub + 20 village pages |
| `prices/` | Price guide page |
| `train-station/` | Train station transfers |
| `long-distance/` | Long distance service |
| `delivery-service/` | Delivery service |
| `pub-club-taxi/` | Pub & club taxi |
| `about/` | About O2Taxi |
| `contact/` | Contact page |
| `book/` | Booking page |
| `blog/` | Blog index |
| `style.css` | All styling |
| `components.js` | Nav + footer (shared) |
| `sitemap.xml` | 37 URLs for Google Search Console |
| `robots.txt` | Crawler instructions |
| `_redirects` | Redirects old Google Sites URLs → new URLs |
| `_headers` | Security + caching headers |

## Total Pages: 37 indexed URLs

---

## Step 1 – Upload to GitHub

1. Create a free account at github.com
2. Click **New Repository** → name it `o2taxi-website` → **Create**
3. Upload all files keeping the folder structure intact
   - Drag and drop the whole folder, or use GitHub Desktop

## Step 2 – Deploy to Cloudflare Pages

1. Go to **dash.cloudflare.com** → sign in or create free account
2. Go to **Pages** → **Create a Project** → **Connect to Git**
3. Select your GitHub repo `o2taxi-website`
4. Build settings:
   - **Framework preset:** None
   - **Build command:** *(leave blank)*
   - **Build output directory:** `/` (root)
5. Click **Save and Deploy**

Your site will be live at `o2taxi-website.pages.dev` within 2 minutes.

## Step 3 – Connect Your Domain (www.o2taxi.com)

1. In Cloudflare Pages → your project → **Custom Domains**
2. Click **Set up a custom domain** → enter `www.o2taxi.com`
3. Follow the DNS instructions (add a CNAME record pointing to your Pages URL)
4. Also add `o2taxi.com` (without www) and set it to redirect to `www.o2taxi.com`

## Step 4 – Google Search Console

1. Go to **search.google.com/search-console**
2. Add property: `https://www.o2taxi.com`
3. Verify via **HTML tag** (add the meta tag to `<head>` in `index.html`)
4. Submit sitemap: go to **Sitemaps** → enter `https://www.o2taxi.com/sitemap.xml` → Submit
5. Request indexing for your homepage

## Step 5 – Google Business Profile

1. Go to **business.google.com**
2. Update your website URL to `https://www.o2taxi.com`
3. Make sure your name, address, phone match exactly what's on the site

## SEO Notes

- All 37 pages have unique titles, meta descriptions and canonical URLs
- JSON-LD schema markup on homepage and key pages
- Old Google Sites URLs are redirected (no broken links)
- Sitemap covers all pages for fast Google indexing
- WhatsApp booking links include pre-filled messages for better conversion
